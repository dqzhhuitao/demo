%*******************************************************************************
%* File name     : lay_comp_inin.m  
%* Project       : GEN1_MIL_FULL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V01 NT 10 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

disp (' LAY CD_MC Initialisation');

CD_MC_FeildWeaken_Init;
CD_MC_ModeRun_Init;
CD_MC_FOC_Init;
CD_MC_ThetaSpd_Init;
CD_MC_GetSinCos_Init;
disp ('  LAY CD_MC Initialisation Completed');