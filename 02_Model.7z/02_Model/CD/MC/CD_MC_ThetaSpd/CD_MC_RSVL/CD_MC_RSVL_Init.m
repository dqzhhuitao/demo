%*******************************************************************************
%* File name     : lay_comp_mod_inin.m
%* Project       : GEN1_MIL_FULL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V01 NT 10 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

disp (' CD_MC_RSVL Initialisation');

xml2ws('CD_MC_RSVL.xml')
    
%*******************************************************************************
% P a r a m e t e r  V a l u e 

%% COMPMOD_Parameter.Value = 0;

disp (' CD_MC_RSVL Initialisation Completed');
