%*******************************************************************************
%* File name     : lay_comp_inin.m  
%* Project       : GEN1_MIL_FULL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V01 NT 10 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

disp (' LAY CD_MC Initialisation');

CD_MC_OpenSpdTheta_Init;
CD_MC_PLL_Init;
CD_MC_RSVL_Init;
CD_MC_ThetaInterface_Init;
CD_MC_GetSinCos_Init;
CD_MC_SvcThetaLink_Init;
CD_MC_SENLESS_Init;
disp ('  LAY CD_MC Initialisation Completed');