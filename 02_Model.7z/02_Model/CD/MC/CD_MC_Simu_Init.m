%*******************************************************************************
%* File name     : lay_comp_mod_simn_inin.m  
%* Project       : GEN1_MIL_FULL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V01 NT 10 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

close all;
clear all;
clc;

disp ('Start Initialisation');
    CD_MC_Init;
%*******************************************************************************
% S i m u l a t i o n    P a r a m e t e  r s    C  o n f  i g u r a t i o n

    % Simulation Start Time [s]
        START               = 0;
    % Simulation Stop Time  [s] 
        STOP                = 20; %40e-3;
    % Simulation Maximum Step Size [s]
        MaxSS               = 1e-4;
    % Simulation Minimum Step Size [s]
        MinSS               = 1e-12;    
    % Simulation Relative Tolerance [s]
        RelTol              = 1e-3;        
    % Simulation Absolute Tolerance [s]
        AbsTol              = 1e-6;    
    % Simulation Initial Step Size [s]
        InitSS              =1e-12;     
    % Simulation Fixed-Step Size [s]
        FixSS               = 0.00005;     
    
    % Workspace    
        %* Limit Data points to last (Number of points to save)
        Npts                = inf;                       
        %* Decimation (Save Sampled Points Period)
        Ndeci               = 1;
        %* Sample time to workspace
        SampleT             = MaxSS;
        
        MosfetFrequence = 10000;
        
        DeadTime = 0.02;
        MotorPoles = 5;

%*******************************************************************************
% S t i m u l i      D e f i n i t i o n


%*******************************************************************************
% I n c l u d e


    
%*******************************************************************************
% S c h e d u l e r

    SDL_100MICROS            =   0.0000125;
    SDL_250MICROS            =   0.00025;
     
disp ('Initialisation Completed');