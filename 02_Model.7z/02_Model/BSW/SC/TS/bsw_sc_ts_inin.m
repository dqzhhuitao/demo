%*******************************************************************************
%* File name     : lay_comp_stflow_inin.m
%* Project       : AG1_MDL_MIL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V0X NT 06 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

disp ('bsw_sc_ts Initialisation');

xml2ws('bsw_sc_ts.xml');
  
disp ('bsw_sc_ts Initialisation Completed');
