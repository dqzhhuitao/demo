%*******************************************************************************
%* File name     : lay_inin.m  
%* Project       : GEN1_MIL_FULL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V01 NT 10 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

disp ('bsw_dl Initialisation');

bsw_lin_dl_inin;
disp ('bsw_dl Initialisation Completed');