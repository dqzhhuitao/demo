%*******************************************************************************
%* File name     : lay_inin.m  
%* Project       : GEN1_MIL_FULL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V01 NT 10 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

disp ('bsw Initialisation');
bsw_dl_inin;
bsw_sc_ts_inin;
disp ('bsw Initialisation Completed');