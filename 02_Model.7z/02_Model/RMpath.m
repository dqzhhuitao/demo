CurrentPath = pwd;
rmpath(genpath(CurrentPath));%Add CurrentPaht and its subfolders to the search path:
clear CurrentPath;
