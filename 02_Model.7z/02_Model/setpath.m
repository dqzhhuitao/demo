CurrentPath = pwd;
addpath(genpath(CurrentPath));%Add CurrentPaht and its subfolders to the search path:
clear CurrentPath;
bdclose all;
set_param(0,'CharacterEncoding', 'windows-1252');


