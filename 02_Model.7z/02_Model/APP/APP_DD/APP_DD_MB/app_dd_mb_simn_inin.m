%*******************************************************************************
%* File name     : lay_comp_stflow_simn_inin.m  
%* Project       : AG1_MDL_MIL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V0X NT 06 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

close all;
clear all;
clc;

disp ('Start Initialisation');
app_dd_mb_inin;
%*******************************************************************************
% S i m u l a t i o n    P a r a m e t e  r s    C  o n f  i g u r a t i o n

    % Simulation Start Time [s]
        START               = 0;
    % Simulation Stop Time  [s] 
        STOP                = 10; %40e-3;
    % Simulation Maximum Step Size [s]
        MaxSS               = 1e-6;
    % Simulation Minimum Step Size [s]
        MinSS               = 1e-7;    
    % Simulation Relative Tolerance [s]
        RelTol              = 1e-3;        
    % Simulation Absolute Tolerance [s]
        AbsTol              = 1e-6;    
    % Simulation Initial Step Size [s]
        InitSS              = 1e-6;     
    % Simulation Fixed-Step Size [s]
        FixSS               = 0.005;     
    
    % Workspace    
        %* Limit Data points to last (Number of points to save)
        Npts                = inf;                       
        %* Decimation (Save Sampled Points Period)
        Ndeci               = 25;

%*******************************************************************************
% I n c l u d e

    
    
%*******************************************************************************
% S c h e d u l e r

    SDL_250MICROS            =   0.00025;
    SDL_100MICROS            =   0.0001;
disp ('Initialisation Completed');