%*******************************************************************************
%* File name     : app_comp_inin.m  
%* Project       : GEN1_MIL_FULL
%* Description   : 
%* Author        : Jinhua Luo  
%* Service       :  
%*******************************************************************************
%* $Header: $ 
%* !Trace_To     : V01 NT 10 XXXXX 01: DEV REQ: MOD/YY/00.01
%*******************************************************************************

disp (' app dd Initialisation');

app_dd_dh_inin;
app_dd_dm_inin;
app_dd_mb_inin;
app_dd_oc_inin;
app_dd_ot_inin;
app_dd_ov_inin;
app_dd_rsf_inin;
app_dd_sco_inin;
app_dd_tsf_inin;
app_dd_uv_inin;
app_dd_dr_inin;
app_dd_ldv_inin;

disp ('  app dd Initialisation Completed');