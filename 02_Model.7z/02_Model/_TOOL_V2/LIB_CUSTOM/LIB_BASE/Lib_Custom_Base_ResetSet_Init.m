function Lib_Custom_Base_ResetSet_Init(thisBlock)
%================================================================
InternalValue = get_param(thisBlock, 'InternalValue');
DataStoreNameValue = get_param(thisBlock, 'ResetSetName');
if ~strcmp(InternalValue,DataStoreNameValue)
   LnkStat = get_param(thisBlock,'LinkStatus');
   if strcmp(LnkStat,'implicit')
       ResolvedList = GetResolvedList(get_param(thisBlock,'Parent'));
   end
    set_param(thisBlock,'Permissions','ReadWrite');

    UnitDelayPath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','UnitDelay');
    DataStoreWritePath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','DataStoreWrite');
    DataStoreReadPath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','DataStoreRead');
    ElemsLinePath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'Type','line');

    for i=1:length(ElemsLinePath)
        try
        delete_line(ElemsLinePath(i));
        end
    end
    if(~isempty(UnitDelayPath))
       delete_block(UnitDelayPath);
    end
    if(~isempty(DataStoreWritePath))
       delete_block(DataStoreWritePath);
    end
    if(~isempty(DataStoreReadPath))
       delete_block(DataStoreReadPath);
    end
    
    Constant1PortHdl = get_param([thisBlock '/Constant4'],'PortHandles');
    Constant2PortHdl = get_param([thisBlock '/Constant5'],'PortHandles');
    SetPortHdl       = get_param([thisBlock '/Set'],'PortHandles');
    ResetPortHdl     = get_param([thisBlock '/Reset'],'PortHandles');
    OutPortHdl       = get_param([thisBlock '/Out'],'PortHandles');
    Switch1PortHdl   = get_param([thisBlock '/Switch2'],'PortHandles');
    Switch2PortHdl   = get_param([thisBlock '/Switch3'],'PortHandles');
    add_line(thisBlock,Constant1PortHdl.Outport,Switch1PortHdl.Inport(1));
    add_line(thisBlock,SetPortHdl.Outport,Switch1PortHdl.Inport(2));
    add_line(thisBlock,Constant2PortHdl.Outport,Switch2PortHdl.Inport(1));
    add_line(thisBlock,ResetPortHdl.Outport,Switch2PortHdl.Inport(2));
    add_line(thisBlock,Switch1PortHdl.Outport,Switch2PortHdl.Inport(3));
    add_line(thisBlock,Switch2PortHdl.Outport,OutPortHdl.Inport);
    
    if(isempty(DataStoreNameValue))
       thisBlockDelay = [thisBlock '/UnitDelay'];
       add_block('built-in/UnitDelay',thisBlockDelay,'Position',[470   214   515   246]);
       set_param(thisBlockDelay,'Orientation','left');
       set_param(thisBlockDelay,'SampleTime','-1');
       UDelayPortHdl = get_param(thisBlockDelay,'PortHandles');
       add_line(thisBlock,Switch2PortHdl.Outport,UDelayPortHdl.Inport);
       add_line(thisBlock,UDelayPortHdl.Outport,Switch1PortHdl.Inport(3));
       set_param(thisBlock,'AttributesFormatString','');
    else
       thisBlockWr = [thisBlock '/UnitDelayWrite'];
       thisBlockRd = [thisBlock '/UnitDelayRead'];
       add_block('built-in/DataStoreWrite',thisBlockWr,'Position',[560   199   795   231]);
       add_block('built-in/DataStoreRead',thisBlockRd,'Position',[165   204   395   236]);
       set_param(thisBlockWr,'DataStoreName',DataStoreNameValue);
       set_param(thisBlockWr,'priority','1');
       WrPortHdl = get_param(thisBlockWr,'PortHandles');
       add_line(thisBlock,Switch2PortHdl.Outport,WrPortHdl.Inport);
       set_param(thisBlockRd,'DataStoreName',DataStoreNameValue);
       set_param(thisBlockRd,'priority','0');
       RdPortHdl = get_param(thisBlockRd,'PortHandles');  
       add_line(thisBlock,RdPortHdl.Outport,Switch1PortHdl.Inport(3));
       set_param(thisBlock,'AttributesFormatString',['RS_DataStoreName = ' DataStoreNameValue]);
    end
    set_param(thisBlock, 'InternalValue',DataStoreNameValue);
    set_param(thisBlock,'Permissions','NoReadOrWrite');
end
%================================================================
end

%% GetResolvedList %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function RestoreList = GetResolvedList(BlockId)
BlocksList = regexp(char(getfullname(BlockId)),'/','split');
ParentBlock = char(BlocksList{1});
k = 1;
RestoreList = {};
for i=2:length(BlocksList)
    ParentBlock = [ParentBlock '/' char(BlocksList{i})];
    if(strcmp(get_param(ParentBlock,'linkstatus'),'resolved'))
        RestoreList{k} = ParentBlock;
        k = k + 1;
    end
end
for j=1:length(RestoreList)
    set_param(RestoreList{j},'linkstatus','inactive');
end
end