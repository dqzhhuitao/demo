function Lib_Custom_Base_UnitDelayWrite_Init(thisBlock)
%================================================================
InternalValue = get_param(thisBlock, 'InternalValue');
DataStoreNameValue = get_param(thisBlock, 'UnitDelayName');
if ~strcmp(InternalValue,DataStoreNameValue)
   LnkStat = get_param(thisBlock,'LinkStatus');
    if strcmp(LnkStat,'implicit')
       ResolvedList = GetResolvedList(get_param(thisBlock,'Parent'));
   end
   set_param(thisBlock,'Permissions','ReadWrite');
    % delete the dest block of the line
    InportBlock = char(find_system(thisBlock,'FollowLinks','on','LookUnderMasks','on','BlockType','Inport'));
    InportLines = get_param(InportBlock,'lineHandles');
    delete_block(get_param(InportLines.Outport,'DstBlockHandle'));
    if(isempty(DataStoreNameValue))
        % add terminator block
        add_block('built-in/Terminator',[thisBlock '/Terminator'],'Position',[190   100   210   120]);
        set_param(thisBlock,'AttributesFormatString','');
    else
        % add DataStoreRead block
        thisBlockWr = [thisBlock '/DataStore'];
        add_block('built-in/DataStoreWrite',thisBlockWr,'Position',[190   100   260   120]);
        set_param(thisBlockWr,'DataStoreName',DataStoreNameValue);
        set_param(thisBlockWr,'priority','1');
        set_param(thisBlock,'AttributesFormatString',['UnitDelayName = ' DataStoreNameValue]);
    end
    set_param(thisBlock, 'InternalValue',DataStoreNameValue);
    set_param(thisBlock,'Permissions','NoReadOrWrite');
end
%================================================================
end

%% GetResolvedList %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function RestoreList = GetResolvedList(BlockId)
BlocksList = regexp(char(getfullname(BlockId)),'/','split');
ParentBlock = char(BlocksList{1});
k = 1;
RestoreList = {};
for i=2:length(BlocksList)
    ParentBlock = [ParentBlock '/' char(BlocksList{i})];
    if(strcmp(get_param(ParentBlock,'linkstatus'),'resolved'))
        RestoreList{k} = ParentBlock;
        k = k + 1;
    end
end
for j=1:length(RestoreList)
    set_param(RestoreList{j},'linkstatus','inactive');
end
end