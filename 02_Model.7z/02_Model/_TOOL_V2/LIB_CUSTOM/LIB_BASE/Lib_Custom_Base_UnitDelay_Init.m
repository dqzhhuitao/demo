function Lib_Custom_Base_UnitDelay_Init(thisBlock)
%================================================================
InternalValue = get_param(thisBlock, 'InternalValue');
DataStoreNameValue = get_param(thisBlock, 'UnitDelayName');
if ~strcmp(InternalValue,DataStoreNameValue)
   LnkStat = get_param(thisBlock,'LinkStatus');
   if strcmp(LnkStat,'implicit')
       ResolvedList = GetResolvedList(get_param(thisBlock,'Parent'));
   end
   set_param(thisBlock,'Permissions','ReadWrite');
    thisInport = [thisBlock '/In1'];
    thisOutport = [thisBlock '/Out1'];

    UnitDelayPath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','UnitDelay');
    DataStoreWritePath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','DataStoreWrite');
    DataStoreReadPath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','DataStoreRead');
    ElemsLinePath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'Type','line');

    for i=1:length(ElemsLinePath)
       delete_line(ElemsLinePath(i));
    end
    if(~isempty(UnitDelayPath))
       delete_block(UnitDelayPath);
    end
    if(~isempty(DataStoreWritePath))
       delete_block(DataStoreWritePath);
    end
    if(~isempty(DataStoreReadPath))
       delete_block(DataStoreReadPath);
    end

    InportPortHdl = get_param(thisInport,'PortHandles');
    OutportPortHdl = get_param(thisOutport,'PortHandles');

    if(isempty(DataStoreNameValue))
       thisBlockDelay = [thisBlock '/UnitDelay'];
       add_block('built-in/UnitDelay',thisBlockDelay,'Position',[270   139   315   171]);
       set_param(thisBlockDelay,'SampleTime','-1');
       UDelayPortHdl = get_param(thisBlockDelay,'PortHandles');
       add_line(thisBlock,InportPortHdl.Outport,UDelayPortHdl.Inport);
       add_line(thisBlock,UDelayPortHdl.Outport,OutportPortHdl.Inport);
       set_param(thisBlock,'AttributesFormatString','');
    else
       thisBlockWr = [thisBlock '/UnitDelayWrite'];
       thisBlockRd = [thisBlock '/UnitDelayRead'];
       add_block('built-in/DataStoreWrite',thisBlockWr,'Position',[175    94   410   126]);
       add_block('built-in/DataStoreRead',thisBlockRd,'Position',[180   184   410   216]);
       set_param(thisBlockWr,'DataStoreName',DataStoreNameValue);
       set_param(thisBlockWr,'priority','1');
       WrPortHdl = get_param(thisBlockWr,'PortHandles');
       add_line(thisBlock,InportPortHdl.Outport,WrPortHdl.Inport);
       set_param(thisBlockRd,'DataStoreName',DataStoreNameValue);
       set_param(thisBlockRd,'priority','0');
       RdPortHdl = get_param(thisBlockRd,'PortHandles');  
       add_line(thisBlock,RdPortHdl.Outport,OutportPortHdl.Inport);
       set_param(thisBlock,'AttributesFormatString',['UnitDelayName = ' DataStoreNameValue]);
    end
    set_param(thisBlock, 'InternalValue',DataStoreNameValue);
    set_param(thisBlock,'Permissions','NoReadOrWrite');
end
%================================================================
end

%% GetResolvedList %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function RestoreList = GetResolvedList(BlockId)
BlocksList = regexp(char(getfullname(BlockId)),'/','split');
ParentBlock = char(BlocksList{1});
k = 1;
RestoreList = {};
for i=2:length(BlocksList)
    ParentBlock = [ParentBlock '/' char(BlocksList{i})];
    if(strcmp(get_param(ParentBlock,'linkstatus'),'resolved'))
        RestoreList{k} = ParentBlock;
        k = k + 1;
    end
end
for j=1:length(RestoreList)
    set_param(RestoreList{j},'linkstatus','inactive');
end
end