function Lib_Custom_Base_UnitDelayDeclaration_Init(thisBlock)
%================================================================
InternalValue = get_param(thisBlock, 'InternalValue');
DataStoreNameValue = get_param(thisBlock, 'UnitDelayName');
OldBlock = char(find_system(thisBlock,'FollowLinks','on','LookUnderMasks','on','BlockType','DataStoreMemory'));
if ~strcmp(InternalValue,DataStoreNameValue)
   LnkStat = get_param(thisBlock,'LinkStatus');
   if strcmp(LnkStat,'implicit')
       ResolvedList = GetResolvedList(get_param(thisBlock,'Parent'));
   end
   set_param(thisBlock,'Permissions','ReadWrite');

    if(~isempty(OldBlock))
        delete_block(OldBlock);
        set_param(thisBlock,'AttributesFormatString','');
    end
    if(~isempty(DataStoreNameValue))
        thisBlockMem = [thisBlock '/UnitDelayMemory'];
        add_block('built-in/DataStoreMemory',thisBlockMem,'Position',[190   100   290   120]);
        set_param(thisBlockMem,'DataStoreName',DataStoreNameValue);
        set_param(thisBlockMem,'StateMustResolveToSignalObject','on');
        set_param(thisBlock,'AttributesFormatString',['UnitDelayName = ' DataStoreNameValue]);
    end
    set_param(thisBlock, 'InternalValue',DataStoreNameValue);
    set_param(thisBlock,'Permissions','NoReadOrWrite');
end
%================================================================
end

%% GetResolvedList %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function RestoreList = GetResolvedList(BlockId)
BlocksList = regexp(char(getfullname(BlockId)),'/','split');
ParentBlock = char(BlocksList{1});
k = 1;
RestoreList = {};
for i=2:length(BlocksList)
    ParentBlock = [ParentBlock '/' char(BlocksList{i})];
    if(strcmp(get_param(ParentBlock,'linkstatus'),'resolved'))
        RestoreList{k} = ParentBlock;
        k = k + 1;
    end
end
for j=1:length(RestoreList)
    set_param(RestoreList{j},'linkstatus','inactive');
end
end