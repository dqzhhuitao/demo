function Lib_Custom_Base_UnitDelayRead_Init(thisBlock)
%================================================================
InternalValue = get_param(thisBlock, 'InternalValue');
DataStoreNameValue = get_param(thisBlock, 'UnitDelayName');
if ~strcmp(InternalValue,DataStoreNameValue)
   LnkStat = get_param(thisBlock,'LinkStatus');
   if ~strcmp(LnkStat,'implicit')
       ResolvedList = GetResolvedList(get_param(thisBlock,'Parent'));
   end
   set_param(thisBlock,'Permissions','ReadWrite');
    thisOutport = [thisBlock '/Out1'];

    ConstantPath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','Constant');
    DataStoreReadPath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'BlockType','DataStoreRead');
    ElemsLinePath = find_system(thisBlock, ...
        'SearchDepth', 1, ...
        'LookUnderMasks', 'on', ...
        'FollowLinks', 'on', ...
        'FindAll', 'on',...
        'Type','line');

    for i=1:length(ElemsLinePath)
       delete_line(ElemsLinePath(i));
    end
    if(~isempty(ConstantPath))
       delete_block(ConstantPath);
    end
    if(~isempty(DataStoreReadPath))
       delete_block(DataStoreReadPath);
    end

    OutportPortHdl = get_param(thisOutport,'PortHandles');

    if(isempty(DataStoreNameValue))
       thisBlockConstant = [thisBlock '/Constant'];
       add_block('built-in/Constant',thisBlockConstant,'Position',[270   139   315   171]);
       set_param(thisBlockConstant,'Value','0');
       ConstantPortHdl = get_param(thisBlockConstant,'PortHandles');
       add_line(thisBlock,ConstantPortHdl.Outport,OutportPortHdl.Inport);
       set_param(thisBlock,'AttributesFormatString','');
    else
       thisBlockRd = [thisBlock '/UnitDelayRead'];
       add_block('built-in/DataStoreRead',thisBlockRd,'Position',[180   184   410   216]);
       set_param(thisBlockRd,'DataStoreName',DataStoreNameValue);
       set_param(thisBlockRd,'priority','0');
       RdPortHdl = get_param(thisBlockRd,'PortHandles');  
       add_line(thisBlock,RdPortHdl.Outport,OutportPortHdl.Inport);
       set_param(thisBlock,'AttributesFormatString',['UnitDelayName = ' DataStoreNameValue]);
    end
    set_param(thisBlock, 'InternalValue',DataStoreNameValue);
    set_param(thisBlock,'Permissions','NoReadOrWrite');
end
%================================================================
end

%% GetResolvedList %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function RestoreList = GetResolvedList(BlockId)
BlocksList = regexp(char(getfullname(BlockId)),'/','split');
ParentBlock = char(BlocksList{1});
k = 1;
RestoreList = {};
for i=2:length(BlocksList)
    ParentBlock = [ParentBlock '/' char(BlocksList{i})];
    if(strcmp(get_param(ParentBlock,'linkstatus'),'resolved'))
        RestoreList{k} = ParentBlock;
        k = k + 1;
    end
end
for j=1:length(RestoreList)
    set_param(RestoreList{j},'linkstatus','inactive');
end
end