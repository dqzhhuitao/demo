function Lib_Custom_Base_Saturation_Init(thisBlock)
%================================================================
ListLine = find_system(thisBlock,'FollowLinks','on','findall','on','LookUnderMasks','all','SearchDepth',1,'Type','line');
ListBLKO = find_system(thisBlock,'FollowLinks','on','SearchDepth',1,'LookUnderMasks','all','BlockType', 'Outport');
BLKOS = get_param(thisBlock,'Blocks');

BHitMax = find_system(thisBlock,'FollowLinks','on','SearchDepth',1,'LookUnderMasks','all','BlockType', 'Outport','Name','HitMax');
BHitMin = find_system(thisBlock,'FollowLinks','on','SearchDepth',1,'LookUnderMasks','all','BlockType', 'Outport','Name','HitMin');
BOut = find_system(thisBlock,'FollowLinks','on','SearchDepth',1,'LookUnderMasks','all','BlockType', 'Outport','Name','Out');

BTHitMax = find_system(thisBlock,'FollowLinks','on','SearchDepth',1,'LookUnderMasks','all','BlockType', 'Terminator','Name','HitMax');
BTHitMin = find_system(thisBlock,'FollowLinks','on','SearchDepth',1,'LookUnderMasks','all','BlockType', 'Terminator','Name','HitMin');
BTOut = find_system(thisBlock,'FollowLinks','on','SearchDepth',1,'LookUnderMasks','all','BlockType', 'Terminator','Name','Out');

if ~isempty(BTHitMax)
    delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
    delete_block([thisBlock,'/HitMax']);
end
if ~isempty(BTHitMin)
    delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
    delete_block([thisBlock,'/HitMin']);
end
if ~isempty(BTOut)
    delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1']);
    delete_block([thisBlock,'/Out']);
end

if isempty(BHitMax)
    add_block('built-in/OutPort',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
    %set_param([thisBlock,'/HitMax'],'DataType','Boolean') %BL
    add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on')
end
set_param([thisBlock,'/HitMax'],'Port','1')
if isempty(BHitMin)
    add_block('built-in/OutPort',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
    %set_param([thisBlock,'/HitMin'],'DataType','Boolean') %BL
    add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
end
set_param([thisBlock,'/HitMin'],'Port','3')
if isempty(BOut)
    add_block('built-in/OutPort',[thisBlock,'/Out'],'Position',[615 138 645 152]);
    add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on')
end
set_param([thisBlock,'/Out'],'Port','2')


if strcmp(get_param([thisBlock,'/MinMax',num2str(1)],'Function'),'min')
    delete_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1']);
    delete_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2']);
    delete_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2']);
    delete_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1']);
elseif strcmp(get_param([thisBlock,'/MinMax',num2str(1)],'Function'),'max')
    delete_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1']);
    delete_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1']);
    delete_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2']);
    delete_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2']);
end


if strcmp(get_param(thisBlock,'FlagMinMax'),'max')
    set_param([thisBlock,'/MinMax',num2str(1)],'Function','max') %
    set_param([thisBlock,'/MinMax',num2str(2)],'Function','min') %
    set_param([thisBlock,'/RO',num2str(1)],'Operator',get_param(thisBlock,'FlagTestHitMax'))
    set_param([thisBlock,'/RO',num2str(2)],'Operator',get_param(thisBlock,'FlagTestHitMin'))
    if  strcmp(get_param(thisBlock,'FlagOut'),'on') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagHitMax'),'on')
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagHitMax'),'on')
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'])
        delete_block([thisBlock,'/Out'])
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagOut'),'on') && strcmp(get_param(thisBlock,'FlagHitMax'),'on')
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagHitMax'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagOut'),'on')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagHitMax'),'on')
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'])
        delete_block([thisBlock,'/Out'])
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagHitMax'),'off')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1']);
        delete_block([thisBlock,'/Out']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on')
    elseif strcmp(get_param(thisBlock,'FlagOut'),'on') && strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagHitMax'),'off')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagHitMax'),'off')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1']);
        delete_block([thisBlock,'/Out']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on')
    end
elseif strcmp(get_param(thisBlock,'FlagMinMax'),'min')
    set_param([thisBlock,'/MinMax',num2str(1)],'Function','min') %
    set_param([thisBlock,'/MinMax',num2str(2)],'Function','max') %
    set_param([thisBlock,'/RO',num2str(1)],'Operator',get_param(thisBlock,'FlagTestHitMax'))
    set_param([thisBlock,'/RO',num2str(2)],'Operator',get_param(thisBlock,'FlagTestHitMin'))
    if strcmp(get_param(thisBlock,'FlagOut'),'on') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagHitMax'),'on')
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagHitMax'),'on')
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1']);
        delete_block([thisBlock,'/Out']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagHitMax'),'on') && strcmp(get_param(thisBlock,'FlagOut'),'on')
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagHitMax'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagOut'),'on')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagHitMax'),'on')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1']);
        delete_block([thisBlock,'/Out']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'on') && strcmp(get_param(thisBlock,'FlagHitMax'),'off')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1']);
        delete_block([thisBlock,'/Out']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on')
    elseif strcmp(get_param(thisBlock,'FlagOut'),'on') && strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagHitMax'),'off')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
    elseif strcmp(get_param(thisBlock,'FlagOut'),'off') && strcmp(get_param(thisBlock,'FlagHitMin'),'off') && strcmp(get_param(thisBlock,'FlagHitMax'),'off')
        delete_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1']);
        delete_block([thisBlock,'/HitMax']);
        delete_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1']);
        delete_block([thisBlock,'/HitMin']);
        delete_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1']);
        delete_block([thisBlock,'/Out']);
        add_line(thisBlock,['SatMax','/1'],['MinMax',num2str(1),'/1'],'autorouting','on')
        add_line(thisBlock,['SatMin','/1'],['MinMax',num2str(2),'/2'],'autorouting','on')
        add_line(thisBlock,['In','/1'],['MinMax',num2str(1),'/2'],'autorouting','on')
        add_line(thisBlock,['MinMax',num2str(1),'/1'],['MinMax',num2str(2),'/1'],'autorouting','on')
        add_block('built-in/Terminator',[thisBlock,'/Out'],'Position',[615 138 645 152]);
        add_line(thisBlock,['MinMax',num2str(2),'/1'],['Out','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/HitMin'],'Position',[275 188 305 202]);
        add_line(thisBlock,['RO',num2str(2),'/1'],['HitMin','/1'],'autorouting','on');
        add_block('built-in/Terminator',[thisBlock,'/HitMax'],'Position',[275 58 305 72]);
        add_line(thisBlock,['RO',num2str(1),'/1'],['HitMax','/1'],'autorouting','on');
    end
end
end


