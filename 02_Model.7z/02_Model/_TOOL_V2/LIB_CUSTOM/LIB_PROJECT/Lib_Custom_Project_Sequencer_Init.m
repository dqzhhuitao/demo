function Lib_Custom_Project_Sequencer_Init(thisBlock)
%================================================================
% Manage bloc contents
%----------------------
% nb of requested function calls

% down top
% plot([0.5 0.5], [0.2 0.8]);
% plot([0.3 0.5], [0.6 0.8]);
% plot([0.5 0.7], [0.8 0.6]);
%
% top down
% plot([0.5 0.5], [0.2 0.8]);
% plot([0.5 0.7], [0.2 0.4]);
% plot([0.5 0.3], [0.2 0.4]);

try
    localNbCalls = str2num(get_param(thisBlock, 'NbCalls'));
catch
    localNbCalls = 1;
end

% nb of outports
localOutportsPath = find_system(thisBlock, ...
    'SearchDepth', 1, ...
    'LookUnderMasks', 'on', ...
    'FollowLinks', 'on', ...
    'FindAll', 'on', ...
    'BlockType', 'Outport');
localNbOutports = length(localOutportsPath);

try
    localTopDownCall = get_param(thisBlock, 'TopDownCall');
catch
    localTopDownCall = 'off';
end

try
    local_oldTopDownCall = get_param(thisBlock, 'old_TopDownCall');
catch
    localTopDownCall = 'off';
    local_oldTopDownCall = 'off';
end

if ((localNbCalls ~= localNbOutports)||(~strcmp(localTopDownCall,local_oldTopDownCall)))
    set_param(thisBlock,'Permissions','ReadWrite');
    try
        set_param(thisBlock, 'old_TopDownCall',localTopDownCall);
    catch
    end
    down_top_display = 'plot([0.5 0.5], [0.2 0.8]);plot([0.3 0.5], [0.6 0.8]);plot([0.5 0.7], [0.8 0.6]);';
    top_down_display = 'plot([0.5 0.5], [0.2 0.8]);plot([0.5 0.7], [0.2 0.4]);plot([0.5 0.3], [0.2 0.4]);';
    
    if (strcmp(localTopDownCall,'off'))
        localDisplay = down_top_display;
    else
        localDisplay = top_down_display;
    end
    
    localMaskDisplay = get_param(thisBlock,'MaskDisplay');
    
    set_param([thisBlock '/Demux'], 'Outputs', get_param(thisBlock, 'NbCalls'));
    % delete lines between demux and outports
    for localIdx = 1:localNbOutports
        localLineHandle = get_param(localOutportsPath(localIdx), 'LineHandles');
        if (localLineHandle.Inport >= 0)
            delete_line(localLineHandle.Inport);
        end
    end
    % add missing ports
    localPort1Pos = get_param(localOutportsPath(1), 'Position');
    for localIdx = (localNbOutports + 1):localNbCalls
        localPortName = ['Out' num2str(localIdx)];
        add_block('built-in/Outport', [thisBlock '/' localPortName], ...
            'Position', localPort1Pos + ...
            [0 ((localIdx - 1) * 30) 0 ((localIdx - 1) * 30)]);
    end
    if (strcmp(localTopDownCall,'off'))
        set_param(thisBlock,'MaskDisplay',down_top_display);
        % connect demux and outports
        for localIdx = 1:localNbCalls
            localPortName = ['Out' num2str(localNbCalls - localIdx + 1)];
            add_line(thisBlock, ['Demux/' num2str(localIdx)], [localPortName '/1']);
        end
    else
        set_param(thisBlock,'MaskDisplay',top_down_display);
        % connect demux and outports
        for localIdx = 1:localNbCalls
            localPortName = ['Out' num2str(localIdx)];
            add_line(thisBlock, ['Demux/' num2str(localIdx)], [localPortName '/1']);
        end
    end
    % delete useless ports
    for localIdx = (localNbCalls + 1):localNbOutports
        % delete port
        delete_block(localOutportsPath(localIdx));
    end
    % Manage bloc position
    %----------------------
    localFixedWidth = 20;
    localPosition = get_param(thisBlock, 'Position');
    if (localPosition(3) ~= (localPosition(1) + localFixedWidth))
        localPosition(3) = localPosition(1) + localFixedWidth;
        set_param(thisBlock, 'Position', localPosition);
    end
    %================================================================
    set_param(thisBlock,'LinkStatus','propagate');
    set_param(thisBlock,'Permissions','ReadOnly');
end
%================================================================
end

