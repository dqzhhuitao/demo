function lib_custom_project_fault_mask(varargin)

global faults;
% inin param
FaultFunction			 = varargin{1};
FaultType				 = varargin{2};
FaultFunctionTypeInc	 = varargin{3};
FaultFunctionTypeDec	 = varargin{4};
FaultFunctionTypeIrr	 = varargin{5};
FaultFunctionTypeAut	 = varargin{6};
FaultFunctionTypeAutLock = varargin{7};
FaultFunctionTypeLevel	 = varargin{8};

% function
evalin('base',['Fault',FaultFunction,FaultType,'Logged = mpt.Signal;']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.Description = ''The signal failure is logged'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.DataType = ''boolean'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.Max = 1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.Dimensions = [1 1];']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.Complexity = ''real'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.SampleTime = -1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.SamplingMode = ''Sample based'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.InitialValue = ''0'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.Alias = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.CustomAttributes.MemorySection = ''Default'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.CustomAttributes.HeaderFile = ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.CustomAttributes.Owner = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.CustomAttributes.DefinitionFile = ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Logged.RTWInfo.CustomAttributes.PersistenceLevel = 1;']);

evalin('base',['Fault',FaultFunction,FaultType,'Detected = mpt.Signal;']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.Description = ''Fault detected on signal'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.DataType = ''boolean'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.Max = 1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.Dimensions = [1 1];']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.Complexity = ''real'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.SampleTime = -1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.SamplingMode = ''Sample based'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.InitialValue = ''0'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.Alias = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.CustomAttributes.MemorySection = ''Default'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.CustomAttributes.HeaderFile = ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.CustomAttributes.Owner = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.CustomAttributes.DefinitionFile = ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Detected.RTWInfo.CustomAttributes.PersistenceLevel = 1;']);

evalin('base',['Fault',FaultFunction,FaultType,'Counter = mpt.Signal;']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.Description = ''Failure counter for the signal diagnostic'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.DataType = ''uint8'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.Max = 255;']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.Dimensions = [1 1];']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.Complexity = ''real'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.SampleTime = -1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.SamplingMode = ''Sample based'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.InitialValue = ''0'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.Alias = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.CustomAttributes.MemorySection = ''Default'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.CustomAttributes.HeaderFile = ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.CustomAttributes.Owner = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.CustomAttributes.DefinitionFile = ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Counter.RTWInfo.CustomAttributes.PersistenceLevel = 1;']);

evalin('base',['Fault',FaultFunction,FaultType,'Aut = mpt.Signal;']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.Description = ''Dynamic authorization of the signal detection'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.DataType = ''boolean'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.Max = 1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.Dimensions = [1 1];']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.Complexity = ''real'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.SampleTime = -1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.SamplingMode = ''Sample based'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.InitialValue = ''',FaultFunctionTypeAut,''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.Alias = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.CustomAttributes.MemorySection = ''Default'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.CustomAttributes.HeaderFile = ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.CustomAttributes.Owner = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.CustomAttributes.DefinitionFile = ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Aut.RTWInfo.CustomAttributes.PersistenceLevel = 1;']);

evalin('base',['FaultLevel = mpt.Signal;']);
evalin('base',['FaultLevel.Description = ''Level failure'';']);
evalin('base',['FaultLevel.DataType = ''uint8'';']);
evalin('base',['FaultLevel.Min = 0;']);
evalin('base',['FaultLevel.Max = 255;']);
evalin('base',['FaultLevel.DocUnits = '''';']);
evalin('base',['FaultLevel.Dimensions = [1 1];']);
evalin('base',['FaultLevel.Complexity = ''real'';']);
evalin('base',['FaultLevel.SampleTime = -1;']);
evalin('base',['FaultLevel.SamplingMode = ''Sample based'';']);
evalin('base',['FaultLevel.InitialValue = ''0'';']);
evalin('base',['FaultLevel.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['FaultLevel.RTWInfo.Alias =  '''';']);
evalin('base',['FaultLevel.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['FaultLevel.RTWInfo.CustomAttributes.MemorySection = ''Default'';']);
evalin('base',['FaultLevel.RTWInfo.CustomAttributes.HeaderFile= ''fault.h'';']);
evalin('base',['FaultLevel.RTWInfo.CustomAttributes.Owner=  '''';']);
evalin('base',['FaultLevel.RTWInfo.CustomAttributes.DefinitionFile= ''fault_def.c'';']);
evalin('base',['FaultLevel.RTWInfo.CustomAttributes.PersistenceLevel=  1;']);

evalin('base',['Fault',FaultFunction,FaultType,'AutLock = mpt.Parameter;']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.Description = ''Dynamic authorization of the signal detection'';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.DataType = ''boolean'';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.Max = 1;']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.Value = ',FaultFunctionTypeAutLock,';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.Alias =  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.CustomAttributes.MemorySection = ''MemConst'';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.CustomAttributes.HeaderFile= ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.CustomAttributes.Owner=  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.CustomAttributes.DefinitionFile= ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'AutLock.RTWInfo.CustomAttributes.PersistenceLevel=  1;']);
			   		 
evalin('base',['Fault',FaultFunction,FaultType,'Irr = mpt.Parameter;']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.Description = ''Irreversibility boolean for the signal failure'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.DataType = ''boolean'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.Max = 1;']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.Value = ',FaultFunctionTypeIrr,';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.Alias =  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.CustomAttributes.MemorySection = ''MemConst'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.CustomAttributes.HeaderFile= ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.CustomAttributes.Owner=  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.CustomAttributes.DefinitionFile= ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Irr.RTWInfo.CustomAttributes.PersistenceLevel=  1;']);

evalin('base',['Fault',FaultFunction,FaultType,'Dec = mpt.Parameter;']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.Description = ''Decrement value of the signal failure counter (tuning)'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.DataType = ''uint8'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.Max = 255;']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.Value = ',FaultFunctionTypeDec,';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.Alias =  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.CustomAttributes.MemorySection = ''MemConst'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.CustomAttributes.HeaderFile= ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.CustomAttributes.Owner=  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.CustomAttributes.DefinitionFile= ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Dec.RTWInfo.CustomAttributes.PersistenceLevel=  1;']);

evalin('base',['Fault',FaultFunction,FaultType,'Inc = mpt.Parameter;']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.Description = ''Increment value of the signal failure counter (tuning)'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.DataType = ''uint8'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.Max = 255;']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.Value = ',FaultFunctionTypeInc,';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.Alias =  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.CustomAttributes.MemorySection = ''MemConst'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.CustomAttributes.HeaderFile= ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.CustomAttributes.Owner=  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.CustomAttributes.DefinitionFile= ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Inc.RTWInfo.CustomAttributes.PersistenceLevel=  1;']);

evalin('base',['Fault',FaultFunction,FaultType,'Level = mpt.Parameter;']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.Description = ''Level of the signal counter sensor failure (tuning)'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.DataType = ''uint8'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.Min = 0;']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.Max = 255;']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.DocUnits = '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.Value = ',FaultFunctionTypeLevel,';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.StorageClass = ''Custom'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.Alias =  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.CustomStorageClass = ''Global'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.CustomAttributes.MemorySection = ''MemConst'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.CustomAttributes.HeaderFile= ''fault.h'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.CustomAttributes.Owner=  '''';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.CustomAttributes.DefinitionFile= ''fault_def.c'';']);
evalin('base',['Fault',FaultFunction,FaultType,'Level.RTWInfo.CustomAttributes.PersistenceLevel=  1;']);

if (strcmp(get_param(gcb,'LinkStatus'),'implicit')) == 0
   set_param(gcb, 'LinkStatus', 'none');

   if (strcmp(get_param([gcb,'/FaultFunctionTypeAutLock'],'Value'),['Fault',FaultFunction,FaultType,'AutLock'])) == 0
      set_param([gcb, '/FaultFunctionTypeAutLock'],'Value',['Fault',FaultFunction,FaultType,'AutLock']);
   end

   if (strcmp(get_param([gcb,'/FaultFunctionTypeIrr'],'Value'),['Fault',FaultFunction,FaultType,'Irr'])) == 0
      set_param([gcb, '/FaultFunctionTypeIrr'],'Value',['Fault',FaultFunction,FaultType,'Irr']);
   end

   if (strcmp(get_param([gcb,'/FaultFunctionTypeDec'],'Value'),['Fault',FaultFunction,FaultType,'Dec'])) == 0
      set_param([gcb, '/FaultFunctionTypeDec'],'Value',['Fault',FaultFunction,FaultType,'Dec']);
   end

   if (strcmp(get_param([gcb,'/FaultFunctionTypeInc'],'Value'),['Fault',FaultFunction,FaultType,'Inc'])) == 0
      set_param([gcb, '/FaultFunctionTypeInc'],'Value',['Fault',FaultFunction,FaultType,'Inc']);
   end

   if (strcmp(get_param([gcb,'/FaultFunctionTypeLevel'],'Value'),['Fault',FaultFunction,FaultType,'Level'])) == 0
      set_param([gcb, '/FaultFunctionTypeLevel'],'Value',['Fault',FaultFunction,FaultType,'Level']);
   end
  
  
   if (strcmp(get_param([gcb,'/FaultFunctionTypeCounterRead'],'DataStoreName'),['Fault',FaultFunction,FaultType,'Counter'])) == 0
      set_param([gcb, '/FaultFunctionTypeCounterRead'],'DataStoreName',['Fault',FaultFunction,FaultType,'Counter']);
   end
   if (strcmp(get_param([gcb,'/FaultFunctionTypeCounterWrite'],'DataStoreName'),['Fault',FaultFunction,FaultType,'Counter'])) == 0
      set_param([gcb, '/FaultFunctionTypeCounterWrite'],'DataStoreName',['Fault',FaultFunction,FaultType,'Counter']);
   end

   if (strcmp(get_param([gcb,'/FaultFunctionTypeAutRead'],'DataStoreName'),['Fault',FaultFunction,FaultType,'Aut'])) == 0
      set_param([gcb, '/FaultFunctionTypeAutRead'],'DataStoreName',['Fault',FaultFunction,FaultType,'Aut']);
   end
   if (strcmp(get_param([gcb,'/FaultFunctionTypeAutWrite'],'DataStoreName'),['Fault',FaultFunction,FaultType,'Aut'])) == 0
      set_param([gcb, '/FaultFunctionTypeAutWrite'],'DataStoreName',['Fault',FaultFunction,FaultType,'Aut']);
   end

   if (strcmp(get_param([gcb,'/FaultFunctionTypeLoggedRead'],'DataStoreName'),['Fault',FaultFunction,FaultType,'Logged'])) == 0
      set_param([gcb, '/FaultFunctionTypeLoggedRead'],'DataStoreName',['Fault',FaultFunction,FaultType,'Logged']);
   end    
   
   if (strcmp(get_param([gcb,'/FaultFunctionTypeLoggedWrite'],'DataStoreName'),['Fault',FaultFunction,FaultType,'Logged'])) == 0
      set_param([gcb, '/FaultFunctionTypeLoggedWrite'],'DataStoreName',['Fault',FaultFunction,FaultType,'Logged']);
   end    
 
   if (strcmp(get_param([gcb,'/FaultFunctionTypeDetectedWrite'],'DataStoreName'),['Fault',FaultFunction,FaultType,'Detected'])) == 0
      set_param([gcb, '/FaultFunctionTypeDetectedWrite'],'DataStoreName',['Fault',FaultFunction,FaultType,'Detected']);
   end    
end
