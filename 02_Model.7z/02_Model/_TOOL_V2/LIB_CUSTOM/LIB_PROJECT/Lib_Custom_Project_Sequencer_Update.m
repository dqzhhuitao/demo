function Lib_Custom_Project_Sequencer_Update()
old_warning = warning();
warning off;
thisBlock = gcb;

set_param(thisBlock, 'LinkStatus', 'none')
set_param(thisBlock,'Permissions','ReadWrite');

try
    localNbCalls = str2num(get_param(thisBlock, 'NbCalls'));
catch
    localNbCalls = 1;
end
localNbCallsStr = num2str(localNbCalls);

set_param(thisBlock,'MaskInitialization','Lib_Custom_Project_Sequencer_Init(gcb)');
%====================================================================
LocalMaskPromptString                 = 'Number of function calls:|Top down call:|-';
LocalMaskStyleString                  = 'edit,checkbox,checkbox';
LocalMaskTunableValueString           = 'off,on,off';
LocalMaskCallbackString               = '||';
LocalMaskEnableString                 = 'on,on,off';
LocalMaskVisibilityString             = 'on,on,off';
LocalMaskToolTipString                = 'on,on,on';
LocalMaskVarAliasString               = ',,';
LocalMaskVariables                    = 'NbCalls=@1;TopDownCall=@2;old_TopDownCall=&3;';
LocalMaskValueString                  = ['' localNbCallsStr '|off'];
LocalMaskTabNameString                = ',,';
%====================================================================
set_param(thisBlock,'MaskSelfModifiable', 'on');
try
    set_param(thisBlock,'MaskVariables',LocalMaskVariables);
    %====================================================================
    set_param(thisBlock,'MaskPromptString',LocalMaskPromptString);
    set_param(thisBlock,'MaskStyleString',LocalMaskStyleString);
    set_param(thisBlock,'MaskTunableValueString',LocalMaskTunableValueString);
    set_param(thisBlock,'MaskCallbackString',LocalMaskCallbackString);
    set_param(thisBlock,'MaskEnableString',LocalMaskEnableString);
    set_param(thisBlock,'MaskVisibilityString',LocalMaskVisibilityString);
    set_param(thisBlock,'MaskToolTipString',LocalMaskToolTipString);
    set_param(thisBlock,'MaskVarAliasString',LocalMaskVarAliasString);
    set_param(thisBlock,'MaskValueString',LocalMaskValueString);
    set_param(thisBlock,'MaskTabNameString',LocalMaskTabNameString);
    %====================================================================
catch
    %====================================================================
end
set_param(thisBlock,'LinkStatus','propagate');
set_param(thisBlock,'Permissions','ReadOnly');
warning(old_warning);
end