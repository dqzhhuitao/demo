function Lib_Custom_Project_SwitchFcnCall_Init(thisBlock)
%================================================================
thisCasesNbr = eval(get_param(thisBlock, 'CasesNbr'));
thisHasDefault = get_param(thisBlock, 'HasDefault');
thisOldCasesNbr = eval(get_param(thisBlock, 'OldCasesNbr'));
thisOldHasDefault = get_param(thisBlock, 'OldHasDefault');
if(~strcmp(thisOldHasDefault,thisHasDefault) ||...
        (thisOldCasesNbr ~= thisCasesNbr))
    
    load_system('simulink');
    ActionRef = ['simulink/Ports &' sprintf('\n') 'Subsystems/If Action' sprintf('\n') 'Subsystem'];
    FcnCallRef = ['simulink/Ports &' sprintf('\n') 'Subsystems/Function-Call' sprintf('\n') 'Generator'];
    
    LnkStat = get_param(thisBlock,'LinkStatus');
    if strcmp(LnkStat,'implicit')
        ResolvedList = GetResolvedList(get_param(thisBlock,'Parent'));
    end
    set_param(thisBlock,'Permissions','ReadWrite');
    set_param(thisBlock,'OldHasDefault',thisHasDefault);
    set_param(thisBlock,'OldCasesNbr',num2str(thisCasesNbr));
    localOutportsPath = find_system(thisBlock, 'SearchDepth', 1,...
        'LookUnderMasks', 'on', 'FollowLinks', 'on', 'FindAll', 'on',...
        'BlockType', 'Outport');
    localActionsPath = find_system(thisBlock, 'SearchDepth', 2,...
        'LookUnderMasks', 'on', 'FollowLinks', 'on', 'FindAll', 'on',...
        'BlockType', 'ActionPort');
    localDecisionPath = find_system(thisBlock,'regexp', 'on',...
        'LookUnderMasks', 'on', 'FollowLinks', 'on', 'BlockType', 'If|SwitchCase');
    localCasesPath = get_param(localActionsPath,'Parent');
    localConversionPath = find_system(thisBlock,'regexp', 'on',...
        'LookUnderMasks', 'on', 'FollowLinks', 'on',...
        'BlockType', 'DataTypeConversion');
    
    localDecisionPos = [180   100   280   140];
    localCase1Pos = [400   125   480   150];
    localPort1Pos = [580   132   610   148];
    localConversionPorts = get_param(localConversionPath,'PortHandles');
    try
        localSwitchLines = get_param(localDecisionPath,'LineHandles');
        delete_line(localSwitchLines{1}.Outport);
        delete_line(localSwitchLines{1}.Inport);
        localCasesLines = get_param(localCasesPath,'LineHandles');
    catch
        localSwitchLines = {};
        localCasesLines = {};
    end
    %%% delete elements
    % Decision
    try
        delete_block(localDecisionPath);
    catch
    end
    % Cases lines
    for localIdx = 1:length(localCasesLines)
        if (length(localCasesLines) > 1)
            delete_line(localCasesLines{localIdx}.Outport);
        else
            delete_line(localCasesLines.Outport);
        end
    end
    % Cases and Outports
    if length(localOutportsPath) > 1
        for localIdx = 1:length(localOutportsPath)
            delete_block(localCasesPath(localIdx));
            delete_block(localOutportsPath(localIdx));
        end
    else
        delete_block(localCasesPath);
        delete_block(localOutportsPath);
    end
    
    %%% Processing Mask
    
    %%% add blocks
    if((thisCasesNbr == 0) || (isempty(thisCasesNbr)))
        DecisionBlock = [thisBlock '/If'];
        add_block('built-in/If',DecisionBlock,'Position',localDecisionPos);
        set_param(DecisionBlock, 'IfExpression', 'u1 > 0');
        %     ShowStr{1} = 'if(Enable > 0)';
        CasesDim = 1;
        if(strcmp(thisHasDefault,'on'))
            set_param(DecisionBlock,'ShowElse','on');
        else
            set_param(DecisionBlock,'ShowElse','off');
        end
    elseif(thisCasesNbr == 1)
        DecisionBlock = [thisBlock '/If'];
        add_block('built-in/If',DecisionBlock,'Position',localDecisionPos);
        set_param(DecisionBlock, 'IfExpression', 'u1 == 1');
        CasesDim = 1;
        %     ShowStr{1} = 'if(Enable == 1)';
        if(strcmp(thisHasDefault,'on'))
            set_param(DecisionBlock,'ShowElse','on');
        else
            set_param(DecisionBlock,'ShowElse','off');
        end
    elseif((thisCasesNbr > 1) && (int32(thisCasesNbr)==thisCasesNbr))
        DecisionBlock = [thisBlock '/SwitchCase'];
        add_block('built-in/SwitchCase',DecisionBlock,'Position',localDecisionPos);
        %     ShowStr{1} = 'case0';
        thisStrCases = '{0';
        for i = 1 : thisCasesNbr-1
            thisStrCases = [thisStrCases ',' num2str(i)];
        end
        thisStrCases = [thisStrCases '}'];
        set_param(DecisionBlock, 'CaseConditions', thisStrCases);
        CasesDim = thisCasesNbr;
        if(strcmp(thisHasDefault,'on'))
            set_param(DecisionBlock,'CaseShowDefault','on');
        else
            set_param(DecisionBlock,'CaseShowDefault','off');
        end
    else
        DecisionBlock = [thisBlock '/If'];
        add_block('built-in/If',DecisionBlock,'Position',localDecisionPos);
        set_param(DecisionBlock, 'IfExpression', 'u1 > 0');
        %     ShowStr{1} = 'if(Enable > 0)';
        CasesDim = 1;
        if(strcmp(thisHasDefault,'on'))
            set_param(DecisionBlock,'ShowElse','on');
        else
            set_param(DecisionBlock,'ShowElse','off');
        end
    end
    DecisionPorts = get_param(DecisionBlock,'PortHandles');
    
    for localIdx = 1:CasesDim
        if strcmp(DecisionBlock,[thisBlock '/SwitchCase'])
            localPortName = ['case' char(num2str(localIdx-1))];
            localCaseName = [thisBlock '/CaseAction_' char(num2str(localIdx-1))];
            %       ShowStr{localIdx} = ['case' char(num2str(localIdx-1))];
        else
            localPortName = 'if';
            localCaseName = [thisBlock '/IfAction_' char(num2str(localIdx-1))];
        end
        
        add_block('built-in/Outport', [thisBlock '/' localPortName], ...
            'Position', localPort1Pos + ...
            [0 ((localIdx - 1) * 80) 0 ((localIdx - 1) * 80)]);
        add_block(ActionRef, localCaseName, 'Position', localCase1Pos + [0 ((localIdx - 1) * 80) 0 ((localIdx - 1) * 80)]);
        set_param(localCaseName,'RTWSystemCode','Inline');
        thisPosition = get_param([localCaseName '/In1'],'position');
        delete_block([localCaseName '/In1']);
        add_block(FcnCallRef,[localCaseName '/In1'],'Position',thisPosition);
        set_param([localCaseName '/In1'],'Sample_time','-1');
        CasePorts = get_param(localCaseName,'PortHandles');
        OutportPorts = get_param([thisBlock '/' localPortName],'PortHandles');
        add_line(thisBlock, DecisionPorts.Outport(localIdx),CasePorts.Ifaction);
        add_line(thisBlock, CasePorts.Outport,OutportPorts.Inport);
    end
    if(strcmp(thisHasDefault,'on'))
        if(strcmp(DecisionBlock,[thisBlock '/SwitchCase']))
            localPortName = 'default';
            %         ShowStr{CasesDim+1} = 'default';
            localCaseName = [thisBlock '/CaseAction_default'];
        else
            localPortName = 'else';
            %         ShowStr{CasesDim+1} = 'else';
            localCaseName = [thisBlock '/IfAction_else'];
        end
        
        add_block('built-in/Outport', [thisBlock '/' localPortName], ...
            'Position', localPort1Pos + [0 (CasesDim * 80) 0 (CasesDim * 80)]);
        add_block(ActionRef, localCaseName,...
            'Position', localCase1Pos + [0 (CasesDim * 80) 0 (CasesDim * 80)]);
        thisPosition = get_param([localCaseName '/In1'],'position');
        set_param(localCaseName,'RTWSystemCode','Inline');
        delete_block([localCaseName '/In1']);
        add_block(FcnCallRef,[localCaseName '/In1'],'Position',thisPosition);
        set_param([localCaseName '/In1'],'Sample_time','-1');
        CasePorts = get_param(localCaseName,'PortHandles');
        OutportPorts = get_param([thisBlock '/' localPortName],'PortHandles');
        add_line(thisBlock, DecisionPorts.Outport(CasesDim+1),CasePorts.Ifaction);
        add_line(thisBlock, CasePorts.Outport,OutportPorts.Inport);
    end
    add_line(thisBlock, localConversionPorts{1}.Outport,DecisionPorts.Inport);
    set_param(thisBlock,'Permissions','NoReadOrWrite');
end
end

%% GetResolvedList %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function RestoreList = GetResolvedList(BlockId)
BlocksList = regexp(char(getfullname(BlockId)),'/','split');
ParentBlock = char(BlocksList{1});
k = 1;
RestoreList = {};
for i=2:length(BlocksList)
    ParentBlock = [ParentBlock '/' char(BlocksList{i})];
    if(strcmp(get_param(ParentBlock,'linkstatus'),'resolved'))
        RestoreList{k} = ParentBlock;
        k = k + 1;
    end
end
for j=1:length(RestoreList)
    set_param(RestoreList{j},'linkstatus','inactive');
end
end