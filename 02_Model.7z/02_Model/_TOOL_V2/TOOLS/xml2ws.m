function xml2ws(FileName,OverWrite)
% XML2WS write workspace from XML file.
%   XML2WS(FILENAME) loads all data stored in XML file named FILENAME to
%   base workspace.
%
%   See also ws2xml.
%
%

%%
if nargin == 0 || ~ischar(FileName)
    error('Argument FileName must be a string');
end
if nargin < 2
    OverWrite = true;
end 
if ~islogical(OverWrite)
   error('Argument OverWrite must be logical');
end

% Read XML file
docNode = xmlread(FileName);
docRootNode = docNode.getDocumentElement;
dataRootNode = docRootNode.getFirstChild;
docLength = docRootNode.getLength / 2;

% Uncomment for debugging
% dbstop if error;

% Explorer root element 1st level childs
h=waitbar(0,'xml2ws');
for i=1:docLength

    waitbar(i/docLength,h);

    % Skip blank elements between elements
    dataRootNode = dataRootNode.getNextSibling();
    
    % Read data name
    dataName = char(dataRootNode.getNodeName());
    
    if(OverWrite || (~OverWrite && ~evalin('base',['exist(''' dataName ''')'])))
        % Read attributes
        attributeMap = dataRootNode.getAttributes();
        if ~isempty(attributeMap.getNamedItem('Class'))
            dataClassName = attributeMap.getNamedItem('Class').getValue;
            CheckClassDefine(dataClassName); % Check if class is defined
            dataClassName = char(dataClassName);
        else
            dataClassName = 'double';
        end

        % Exeplore current data recursivly
        sub_xml2data(dataName,dataClassName,docNode,dataRootNode)

    else
        fprintf('Skipped data %s overwrite\n',dataName);
    end

    
    dataRootNode = dataRootNode.getNextSibling;
end

waitbar(1,h);
fprintf('Done reading %s !\n',FileName);
close(h);
return;
%%


function sub_xml2data(dataName,dataClassName,docNode,dataRootNode)
%%

% If current data is complex
if dataRootNode.getChildNodes.getLength > 1
    if ~strcmp(dataClassName,'embedded.fi')
        try
            evalin('base',[dataName ' = ' dataClassName ';']);
        catch
            if(strcmp(dataClassName,'Simulink.ParamRTWInfo') ||...
               strcmp(dataClassName,'Simulink.SignalRTWInfo'))
                sub_RTWIdata(dataName,dataClassName,docNode,dataRootNode);
            end;
%           disp('Class with no constructor as a part of another one!');
        end;
       % Explore recursivly
       childNode = dataRootNode.getFirstChild();
       childLength = dataRootNode.getChildNodes().getLength() / 2;
       for i=1:childLength
           % Skip blank elements between elements
           childNode = childNode.getNextSibling();
           
           % Write child data to workspace
           childDataName = [dataName '.' char(childNode.getNodeName())];
           childDataName = regexprep(childDataName, '.[^a-zA-Z0-9][_]([0-9]*)[_]', '($1)');

           childAttributeMap = childNode.getAttributes();
           if ~isempty(childAttributeMap.getNamedItem('Class'))
              childDataClassName = childAttributeMap.getNamedItem('Class').getValue();
              CheckClassDefine(childDataClassName); % Check if class is defined
              childDataClassName = char(childDataClassName);
           else
              childDataClassName = '';
           end

           if strcmp(childDataClassName,'embedded.fi')
              sub_fidata(childDataName,childDataClassName,docNode,childNode);
        else
              sub_xml2data(childDataName,childDataClassName,docNode,childNode);
           end
           childNode = childNode.getNextSibling();
       end
    else
       sub_fidata(dataName,dataClassName,docNode,dataRootNode);
    end
else
    % Else write current data to workspace
    dataValue = char(dataRootNode.getChildNodes.getTextContent());
    % If value is empty, replace by two quotes (empty string)
    if ~isempty(dataValue)
        try
           % If attribute is complex init structure
           if(  ~strcmp(dataClassName,'double') ...
             && ~strcmp(dataClassName,'single') ...
             && ~strcmp(dataClassName,'logical') ...
             && ~strcmp(dataClassName,'char') ...
             && ~strcmp(dataClassName,'cell') ...
             && ~strcmp(dataClassName,'struct') ... 
             && ~strcmp(dataClassName,'function_handle') ...
             && ~strcmp(dataClassName,'int8') ...
             && ~strcmp(dataClassName,'uint8') ...
             && ~strcmp(dataClassName,'int16')  ...
             && ~strcmp(dataClassName,'uint16') ...
             && ~strcmp(dataClassName,'int32') ...
             && ~strcmp(dataClassName,'uint32') ...
             && ~strcmp(dataClassName,'int64') ...
             && ~strcmp(dataClassName,'uint64') ...
             )
              evalin('base',[dataName ' = ' dataClassName '(' dataValue ');']);
           else
               % Special characters handling
               if(~isempty(regexp(dataValue,'''.*''.*''','match')))
                   [dataValueMatch dataValueSplit] = regexp(dataValue,'''','match','split');
                   for i=2:length(dataValueMatch)-1
                       dataValueMatch{i} = ''''''; % replacement value
                   end;
                   j = [dataValueSplit; [dataValueMatch {''}]];
                   dataValue = [j{:}];
               end;
              evalin('base',[dataName ' = ' dataClassName '(' dataValue ');']);
           end
        catch
        % warning('Unable to write %s in %s !\n',dataValue,dataName);
        end
    end
end

return;
%%



function sub_fidata(dataName,dataClassName,docNode,dataRootNode)
%%
        dataValue = '';
        dataTypeMode = '';
        dataSigned = '';
        dataWordLength = '';
        dataFractionLength = '';
        dataSlope = '';
        dataBias = '';

        childNode = dataRootNode.getFirstChild();
        childLength = dataRootNode.getChildNodes().getLength() / 2;
        for i=2:childLength
           % Skip blank elements between elements
           childNode = childNode.getNextSibling();
           childDataName = [dataName '.' char(childNode.getNodeName())];
           childDataArg = char(childNode.getNodeName());
           childDataValue = char(childNode.getChildNodes.getTextContent());
           childAttributeMap = childNode.getAttributes();
           if ~isempty(childAttributeMap.getNamedItem('Class'))
              childDataClassName = childAttributeMap.getNamedItem('Class').getValue();
              CheckClassDefine(childDataClassName); % Check if class is defined
              childDataClassName = char(childDataClassName);
           else
              childDataClassName = '';
           end
           if ~isempty(childDataArg)
              try
                 switch childDataArg
                    case {'Value'}
                    dataValue = childDataValue;
                    case {'DataTypeMode'}
                    dataTypeMode = childDataValue;
                    case {'Signed'}
                    dataSigned = childDataValue;
                    case {'WordLength'}
                    dataWordLength = childDataValue;
                    case {'FractionLength'}
                    dataFractionLength = childDataValue;
                    case {'Slope'}
                    dataSlope = childDataValue;
                    case {'Bias'}
                    dataBias = childDataValue;
                 end
              catch
              % warning('Unable to write %s in %s !\n',childDataValue,childDataName);
              end
           end
           childNode = childNode.getNextSibling();
        end

        if strcmp(dataTypeMode,'Fixed-point: binary point scaling')
           evalin('base',[dataName ' = ' dataClassName '(' dataValue ',' dataSigned ',' dataWordLength ',' dataFractionLength ');']);
        end
        if strcmp(dataTypeMode,'Fixed-point: slope and bias scaling')
           evalin('base',[dataName ' = ' dataClassName '(' dataValue ',' dataSigned ',' dataWordLength ',' dataSlope ',' dataBias ');']);
        end
return;
%%


function sub_RTWIdata(dataName,dataClassName,docNode,dataRootNode)
%%
        dataAlias = '';
        dataCustonAttributes = '';
        dataCustomStorageClass = 'Default';
        dataStorageClass = 'Auto';
        
        ObjectName = 'data_temp_obj';
        if strcmp(dataClassName,'Simulink.ParamRTWInfo')
            evalin('base',[ObjectName ' = Simulink.Parameter;']);
        else
             evalin('base',[ObjectName ' = Simulink.Signal;']);
        end;
        
        childNode = dataRootNode.getFirstChild();
        childLength = dataRootNode.getChildNodes().getLength() / 2;
        for i=2:childLength
           % Skip blank elements between elements
           childNode = childNode.getNextSibling();
           childDataName = [dataName '.' char(childNode.getNodeName())];
           childDataArg = char(childNode.getNodeName());
           childDataValue = char(childNode.getChildNodes.getTextContent());
           childAttributeMap = childNode.getAttributes();
           if ~isempty(childAttributeMap.getNamedItem('Class'))
              childDataClassName = childAttributeMap.getNamedItem('Class').getValue();
              CheckClassDefine(childDataClassName); % Check if class is defined
              childDataClassName = char(childDataClassName);
           else
              childDataClassName = '';
           end
           if ~isempty(childDataArg)
              try
                 switch childDataArg
                    case {'Alias'}
                    dataAlias = childDataValue;
                    case {'CustomAttributes'}
                    dataCustonAttributes = childDataValue;
                    case {'CustomStorageClass'}
                    dataCustomStorageClass = childDataValue;
                    case {'StorageClass'}
                    dataStorageClass = childDataValue;
                 end
              catch
              % warning('Unable to write %s in %s !\n',childDataValue,childDataName);
              end
           end
           childNode = childNode.getNextSibling();
        end
        if ~strcmp(dataAlias,'')
            evalin('base',[ObjectName '.RTWInfo.Alias = ' dataAlias ';']);
        end;
        if ~strcmp(dataCustonAttributes,'')
            evalin('base',[ObjectName '.RTWInfo.CustonAttributes = ' dataCustonAttributes ';']);
        end;
        evalin('base',[ObjectName '.RTWInfo.CustomStorageClass = ' dataCustomStorageClass ';']);
        evalin('base',[ObjectName '.RTWInfo.StorageClass = ' dataStorageClass ';']);
        evalin('base',[dataName  ' = ' ObjectName '.RTWInfo;']);
        evalin('base',['clear ' ObjectName]);

return;

% Check if class is defined
function CheckClassDefine(Arg_ClassName)
    ClassName = char(Arg_ClassName);
    status = evalin('base',['exist(''' ClassName ''',''class'')']);
    if (status ~= 8)
        disp(['Warning: This class ' ClassName ' is not defined!']);
    end
return;



%%

