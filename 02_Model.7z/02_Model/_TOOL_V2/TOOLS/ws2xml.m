function ws2xml(varargin)
% WS2XML write workspace into XML file.
%   WS2XML() writes all data currently in the base workspace into the XML
%   file named after the current date. 
%
%   WS2XML(FILENAME) writes all data currently in the base workspace into
%   the XML file named FILENAME.
%
%   WS2XML(FILENAME,DATAPATTERN) writes all data corresponding to
%   DATAPATTERN into the XML file named FILENAME.
%
%   See also xml2ws.
%
%

%%

if nargin > 0 && ischar(varargin{1})
    FileName = varargin{1};
else
    FileName = ['WS_' date() '.xml'];
end

if nargin > 1 && ischar([varargin{2:end}])
    CommandLine = 'whos(';
    for i=2:nargin
        if ~isempty(varargin{i})
            CommandLine = [CommandLine,'''',varargin{i},''','];
        end
    end
    CommandLine = [CommandLine(1:end-1),');'];
    dataList = evalin('caller',CommandLine);
else
    dataList = evalin('caller','whos');
end





% Init XML file
docNode = com.mathworks.xml.XMLUtils.createDocument(['WS_' date()]);
docRootNode = docNode.getDocumentElement;
% Sample attribute
% docNodeAtt = docNode.createAttribute('Date');
% docNodeAtt.setValue(date());
% docRootNode.setAttributeNode(docNodeAtt);

% Get data list from base WS
% dataList = evalin('base','whos(''NVM'')');
dataCount = length(dataList);

% Uncomment for debugging
% dbstop if error;
h=waitbar(0,'ws2xml');

% Call recursive function to append datas to current XML tree
for i=1:dataCount
    waitbar(i/dataCount,h);
    % Create sub-tree for each data
    dataRootNode = docNode.createElement(dataList(i).name);
    % Write class as attribute of root element of sub-tree for data
    dataAtt = docNode.createAttribute('Class');
    dataAtt.setValue(dataList(i).class);
    dataRootNode.setAttributeNode(dataAtt);
    
    dataName = dataList(i).name;
    data = evalin('caller',dataName);
    dataClass = class(data);

    sub_data2xml(dataName,data,dataClass,docNode,dataRootNode);
    % Append sub-tree to root-tree
    docRootNode.appendChild(dataRootNode);
end

waitbar(1,h);
% Write XML tree to file
xmlwrite(FileName,docNode);

fprintf('Done writing %s !\n',FileName);
close(h);

return;
%%

function sub_data2xml(localDataName,localData,localDataClass,docNode,dataRootNode)
%%

if(~isempty(localData))
    % If data has simple type
    if isnumeric(localData) || islogical(localData)
        if (~strcmp(localDataClass,'embedded.fi'))
          % Write data to tree and return
          localSize = size(localData);
          if(length(localSize) < 3)
          dataRootNode.appendChild(docNode.createTextNode(mat2str(double(localData))));
          elseif(length(localSize) == 3)
              localString = 'cat( 3';
              for i=1:localSize(3)
                  localString = [localString ',' mat2str(localData(:,:,i))];
              end
              dataRootNode.appendChild(docNode.createTextNode([localString ')']));
          else
              disp('ERROR : could not support 4 or more dimensions arrays!');
          end
          % Write class as attribute of root element of sub-tree for data
          dataAtt = docNode.createAttribute('Class');
          dataAtt.setValue(localDataClass);
          dataRootNode.setAttributeNode(dataAtt);
        else
          sub_fidata(localDataName,localDataClass,docNode,dataRootNode)
        end
    elseif ischar(localData)
        dataRootNode.appendChild(docNode.createTextNode(['''' localData '''']));
        % Write class as attribute of root element of sub-tree for data
        dataAtt = docNode.createAttribute('Class');
        dataAtt.setValue(localDataClass);
        dataRootNode.setAttributeNode(dataAtt);
    elseif iscell(localData)
        str = ['{' sprintf('''%s'',',localData{:}) '}'];
        dataRootNode.appendChild(docNode.createTextNode(str));
        % Write class as attribute of root element of sub-tree for data
        dataAtt = docNode.createAttribute('Class');
        dataAtt.setValue(localDataClass);
        dataRootNode.setAttributeNode(dataAtt);
    else
        % Else, data is struct or handle (pointing to a struct) and need to
        % be explored
        localDataFields = fieldnames(localData);
        localDataFieldCount = length(localDataFields);
        if(localDataFieldCount > 1) % if structure keep walking
            localDataSize = 1;
        else
            localDataSize = length(localData);
        end
        if localDataSize > 1
            dataAtt = docNode.createAttribute('Class');
            dataAtt.setValue(localDataClass);
            dataRootNode.setAttributeNode(dataAtt);
            dataAtt = docNode.createAttribute('Length');
            dataAtt.setValue(num2str(localDataSize));
            dataRootNode.setAttributeNode(dataAtt);
            % In case data is an array of structures re-write the structure
            % fields multiple times
            for j=1:localDataSize
                % Create one sub-tree for each element of array
                if localDataSize > 1
                    tmp = dataRootNode;
                    subNodeName = ['_' num2str(j) '_']
                    dataRootNode = docNode.createElement(subNodeName);
                    % Write class as attribute of root element of sub-tree for data
                    dataAtt = docNode.createAttribute('Class');
                    dataAtt.setValue(localDataClass);
                    dataRootNode.setAttributeNode(dataAtt);
                end
                % Explore data by calling recursively the current function for
                % each field of the current data until data field is simple
                % type
                WalkStructure(j,localData,localDataFieldCount,localDataFields,docNode,...
                dataRootNode,localDataName,localDataClass,'yes');
                % Append sub-sub-tree to sub-tree (in case data is an array of
                % struct)
                if localDataSize > 1
                    tmp.appendChild(dataRootNode);
                    dataRootNode = tmp;
                end
            end
        else
            WalkStructure(1,localData,localDataFieldCount,localDataFields,docNode,...
            dataRootNode,localDataName,localDataClass,'No');
        end
    end
end
%%


function sub_fidata(dataName,dataClassName,docNode,dataRootNode)
%%


    dataAtt = docNode.createAttribute('Class');
    dataAtt.setValue(dataClassName);
    dataRootNode.setAttributeNode(dataAtt);

    item = docNode.createElement('Value');
    item.appendChild(docNode.createTextNode(mat2str(double(evalin('base',dataName)))));
    dataAtt = docNode.createAttribute('Class');
    dataAtt.setValue('double');
    item.setAttributeNode(dataAtt);
    dataRootNode.appendChild(item);

    localData         = evalin('base',dataName);
    localDataFields = fieldnames(localData);
    localDataFieldCount = length(localDataFields);

    for i=1:localDataFieldCount
        item = docNode.createElement(localDataFields{i});
        item.appendChild(docNode.createTextNode(mat2str(evalin('base',[dataName '.' localDataFields{i} ]))));
        dataAtt = docNode.createAttribute('Class');
        localData = evalin('base',[dataName '.' localDataFields{i} ]);
        localDataClass = class(localData);
        dataAtt.setValue(localDataClass);
        item.setAttributeNode(dataAtt);
        dataRootNode.appendChild(item);
    end

return;


function WalkStructure(Arg_idx,Arg_localData,Arg_localDataFieldCount,...
Arg_LocalDataFields,Arg_DocNode,Arg_dataRootNode,Arg_LocalDataName,Arg_localDataClass,Arg_VectorAsk)
    for i=1:Arg_localDataFieldCount
        try
            item = Arg_DocNode.createElement(Arg_LocalDataFields{i});
            % Write class as attribute of root element of sub-tree for data
            dataAtt = Arg_DocNode.createAttribute('Class');
            dataAtt.setValue(Arg_localDataClass);
            Arg_dataRootNode.setAttributeNode(dataAtt);
            
            if(strcmpi(Arg_VectorAsk,'yes'))
                dataName = [Arg_LocalDataName '(' num2str(Arg_idx) ').' Arg_LocalDataFields{i}];
                data = eval(['Arg_localData(' num2str(Arg_idx) ').' Arg_LocalDataFields{i}]);
            else
                dataName = [Arg_LocalDataName '.' Arg_LocalDataFields{i}];
                data = eval(['Arg_localData.' Arg_LocalDataFields{i}]);
            end
            dataClass = class(data);
            sub_data2xml(dataName,data,dataClass,Arg_DocNode,item);
            Arg_dataRootNode.appendChild(item);
        catch
            % prevent from errors when field is not defined.
            % Exp: events Logsout
        end
    end
return;
%%
