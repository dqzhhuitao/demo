filename = gcb;
filename = filename(1:strfind(filename,'_simn')-1);
ws2xml(filename,'APSMS_*');