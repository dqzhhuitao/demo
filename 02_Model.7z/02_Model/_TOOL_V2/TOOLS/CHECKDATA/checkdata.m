function checkdata(varargin)
% Checkdata seek and define undefined data to the WS.
% it's mainly used from Menu Tools as GUI tool, in this case no arg are needed.
% but it could be used from terminal with two Different Configuration.
% 1- Analyse Mdl and (define/update) undefined data.
%    Syntaxe: checkdata('Your_Model_Path')
%
% 2- Generate Hook files from library
%    Caution: if you want to have auto-generated hook files (Only for custom Lib)
%    ,but they may need some modifications to meet your desired configuration.
%    Syntaxe: checkdata('update','LibName1.mdl;LibName2.mdl;...')
%
%#__________________________________ Process _________________________________#%
% Tool parameters
CustomHookFilePrefix     = 'CheckData_Hook'; % CustomHookFilePrefix_<Lib Name>.m
SimulinkDefaultClass     = 'Simulink';        % Default Value
CustomDefaultClass       = 'Simulink';        % Default Value
UseGenericRules          = 'off';             % Define No custom block by generic rules when not found in hook files.(on/off)

% Gui Call
ModeGui = 'False';
if nargin < 1
    Selected_Block = gcb;
    ModeGui = 'True';
else
    Selected_Block = varargin{1};
end

% Console Call
if(~(strcmpi(Selected_Block,'update')))
    % Check if Recursive call to ignore some extrat analyses(fetch,..)
    if(nargin == 3)
        option = varargin{2};        % see if recursive call
        HookFilesList = varargin{3}; % already defined don't fetch hook twice.
    else
        option = '';                 % not a recursive call
    end
    % Fetch All hook files in matlab path
    if(~strcmpi(option,'Recursive'))
        HookFilesList = FetchHook(CustomHookFilePrefix,ModeGui);
    end
    % If block is a valid simulink block
    ParseModel = 'Yes';
    try
        ObjectType = get_param(Selected_Block,'BlockType');
    catch
        Display(['<' Selected_Block '> is Not a valid Simulink Block'],'error',ModeGui);
        ParseModel = 'No';
    end
    
    % Parse Model and Get Bloc Lib Informations.
    if (strcmpi(ParseModel,'yes'))
        if(strcmp(ObjectType,'SubSystem'))    % Check if Block is subsys
            Link_Status = 0;
            if(strcmp(get_param(Selected_Block,'linkstatus'),'resolved'))
                set_param(Selected_Block,'linkstatus','inactive');
                Link_Status = 1;
            end
            All_Graph_Elem = find_system(Selected_Block,'FindAll','on'); % Find all blocks in subsys
            
            for i=2:length(All_Graph_Elem)
                % Switch according to block and lib
                DataStructure={};
                %%%%%%%% Block Analysis %%%%%%%%
                switch get_param(All_Graph_Elem(i),'Type')
                    case 'block'
                        switch get_param(All_Graph_Elem(i),'BlockType')
                            %%%%%%%% Recursive Call or Custom block %%%%%%%%
                            case 'SubSystem'
                                if(strcmpi(get_param(All_Graph_Elem(i),'Mask'),'off')) % Subsystem need Recursive Call
                                    checkdata(All_Graph_Elem(i),'Recursive',HookFilesList);
                                else % Custom block will be solved by hook files
                                    MaskType = get_param(All_Graph_Elem(i),'MaskType');
                                    % Fetch Custom block in lib
                                    for idxHookFile = 1:length(HookFilesList)
                                        paths_Cell = regexp(HookFilesList{idxHookFile},'\\','split');
                                        FuncName = regexprep(paths_Cell{end},'\.m$','');
                                        MaskType = strrep(MaskType,sprintf('%s',''''),sprintf('%s',''''''));
                                        DataStructure = evalin('base',[FuncName '(' '''' MaskType '''' ')' ]);
                                        if(~isempty(DataStructure))
                                            DefineData(All_Graph_Elem(i),DataStructure,CustomDefaultClass,ModeGui);
                                            break;
                                        end
                                    end
                                end
                                
                            otherwise
                                %%%%%%%% Not a Custom blocks %%%%%%%%
                                BlockType = get_param(All_Graph_Elem(i),'BlockType');
                                % process hook files
                                for idxHookFile = 1:length(HookFilesList)
                                    paths_Cell = regexp(HookFilesList{idxHookFile},'\\','split');
                                    FuncName = regexprep(paths_Cell{end},'\.m$','');
                                    BlockType = strrep(BlockType,sprintf('%s',''''),sprintf('%s',''''''));
                                    DataStructure = evalin('base',[FuncName '(' '''' BlockType '''' ')' ]);
                                    if(~isempty(DataStructure))
                                        DefineData(All_Graph_Elem(i),DataStructure,SimulinkDefaultClass,ModeGui);
                                        break;
                                    end
                                end
                                % If block is not found anywhere use generic custom function
                                if(strcmpi(UseGenericRules,'on'))
                                    if(isempty(DataStructure))
                                        Generic_Create_Param_MPT(All_Graph_Elem(i),ModeGui);
                                    end
                                end
                        end

                    otherwise
                        %%%%%%%% Ports,Lines,... %%%%%%%%
                        BlockType = get_param(All_Graph_Elem(i),'Type');
                        % process hook files
                        for idxHookFile = 1:length(HookFilesList)
                            paths_Cell = regexp(HookFilesList{idxHookFile},'\\','split');
                            FuncName = regexprep(paths_Cell{end},'\.m$','');
                            BlockType = strrep(BlockType,sprintf('%s',''''),sprintf('%s',''''''));
                            DataStructure = evalin('base',[ FuncName '(' '''' BlockType '''' ')' ]);
                            if(~isempty(DataStructure))
                                DefineData(All_Graph_Elem(i),DataStructure,SimulinkDefaultClass,ModeGui);
                                break;
                            end
                        end
                end
            end
            daexplr; % Ouvre l'explorateur si un parametre est ajout�
            if Link_Status == 1
                set_param(Selected_Block,'linkstatus','restore');
            end
        else
            Display(['Can''t check data for the block "' getfullname(Selected_Block) '" (it''s not a subsystem)!'],'error',ModeGui);
        end
    end
else
    % Process Options
    if(strcmpi(varargin{1},'update'))
        if(nargin == 2)
            LibNamesList = regexp(varargin{2},';','split');
            % Locate all LIBs
            LIBRARY={};
            LibIdx = 1;
            for i=1:length(LibNamesList)
                LibNames = regexprep(LibNamesList{i},'\.mdl$','');
                LibPath = which([LibNames '.mdl']);
                if (~isempty(LibPath));
                    LIBRARY{LibIdx} = which([LibNames '.mdl']);
                    LibIdx=LibIdx+1;
                else
                    if(~strcmpi(LibNames,''))
                        Display(['<' LibNames '> Not Found.'],'warning',ModeGui);
                    end
                end
            end
            
            % Generate Hook Files
            for idxLib=1:length(LIBRARY)
                Display(['Generating Hook of : ' LIBRARY{idxLib}],'Info',ModeGui);
                if(~isempty(LIBRARY{idxLib}))
                    UpdateBib(LIBRARY{idxLib},CustomHookFilePrefix)
                end
            end
        else
             Display(['No Library is defined! please use <checkdata(''update'',''LibName1.mdl;LibName2.mdl;...'')>'],'error',ModeGui);
        end
    else
        Display(['Unkown option <' varargin{1} '>.'],'error',ModeGui);
    end
end
%#___________________________ The End of Process Section _____________________#%
end

%#______________________________ Main Functions ______________________________#%
% Fetch All lib hook files
function Arg_HookFilesList = FetchHook(Arg_CustomHookFilePrefix,Arg_Mode)
    Arg_HookFilesList = {};
    UniqueFunction    = {};
    HookCnt = 1;
    paths_Str = evalin('base','path');
    paths_Cell = regexp(paths_Str,'\;','split');
    for IdxPath = 1:size(paths_Cell,2)
        FilesStruct = dir(fullfile([paths_Cell{IdxPath}],'*.m'));
        for idxFile =1:size(FilesStruct,1)
            FileName = FilesStruct(idxFile).name;
            if(regexp(FileName,[Arg_CustomHookFilePrefix '(\w*).m']))
                FuncName = regexprep(FileName,'\.m$','');
                if(isvarname(FuncName))
                    DefFileIndx = CheckDefineFile(UniqueFunction,FileName);
                    if(DefFileIndx == 0) % if 0 file is not defined yet.
                        HookPath = [paths_Cell{IdxPath} '\' FileName];
                        Arg_HookFilesList{HookCnt}=HookPath;
                        UniqueFunction{HookCnt} = FileName;
                        HookCnt=HookCnt+1;
                    else
                        Display([FileName ' is already defined in other directory!' sprintf('\n')...
                        '>Used hook: ' Arg_HookFilesList{DefFileIndx} sprintf('\n')...
                        '>Ignored hook: ' paths_Cell{IdxPath} '\' FileName],'error',Arg_Mode);
                    end
                else
                    Display(['<' FileName '> is ignored because it Doesn''t have a correct matlab variable name.'],'warning',Arg_Mode);
                end
            end
        end
    end
end

%% Define Custom block %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DefineData(Arg_BlockId,Arg_Struct,Arg_Class,Arg_Mode)
    for IdxParam=1:length(Arg_Struct)
        ParamHash = regexp(Arg_Struct{IdxParam},'\|','split');
        try
            VarName = get_param(Arg_BlockId,ParamHash{1});
            % Check if class defined in LIB
            if(length(ParamHash)>=3)
                if(~strcmpi(ParamHash{3},''))
                    Arg_Class = ParamHash{3};
                end
            end
            % Check if class defined
            status = evalin('base',['exist(''' Arg_Class ''',''class'')']);
            if ((status ~= 8)&&(~strcmpi(Arg_Class,'mpt')&&(~strcmpi(Arg_Class,'simulink'))))
                Display(['This class ' Arg_Class ' is not defined!'],'warning',Arg_Mode);
            else
                % Add Data to the WS
                if(strcmpi(ParamHash{2},'Signal'))
                    create_signal(Arg_BlockId,ParamHash{1},Arg_Class,'',Arg_Mode);
                else
                    create_parameter(Arg_BlockId,ParamHash{1},Arg_Class,'',Arg_Mode);
                end
            end
        catch ERROR_ID
            Display(['Couldn''''t define this Data ' Arg_Struct{IdxParam}],'error',Arg_Mode);
            ERROR_ID
        end
    end
end

%% create_signal_mpt %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function create_signal_mpt(Line_Id,ParamId)
function create_signal(Arg_Line_Id,Arg_ParamId,Arg_ClassName,Arg_TypeId,Arg_Mode)
    Line_Name = get_param(Arg_Line_Id,Arg_ParamId); % Get Signal Name
    % Check if Signal already exist
    ParamExist = evalin('base',['exist(''' char(Line_Name) ''')']);
    if(ParamExist)
        % update Signal type if possible
        OldType = evalin('base',[Line_Name '.DataType']);
        if (~(strcmpi(Arg_TypeId,''))) && strcmp(OldType,'auto')
            evalin('base',[Line_Name '.DataType =''' Arg_TypeId ''';']);
        end
    else 
        % Define signal in the WS
        if ~strcmpi(Line_Name,'')
            evalin('base',[Line_Name ' = ' Arg_ClassName '.Signal;']);
            if (~(strcmpi(Arg_TypeId,'')))
                evalin('base',[Line_Name '.DataType =' Arg_TypeId ';']);
            end
        else
            if ~strcmp(Arg_ParamId,'Name')
                Block_Name = get_param(Arg_Line_Id,'Name');
                Display(['Signal unnamed in block "' Block_Name '", no corresponding mpt signal is created!'],'warning',Arg_Mode);
            end
        end
    end
end

%% create_parameter_mpt %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function create_parameter(Arg_BlockId,Arg_ParamId,Arg_ClassName,Arg_Rules,Arg_Mode)
    Block_Name = get_param(Arg_BlockId,Arg_ParamId);
    VarName = regexprep(Block_Name, '{', '');
    VarName = regexprep(VarName, '}', '');
    ListVarName = regexp(VarName, '\,', 'split');
    ListVarName = strtrim(ListVarName);

    for ii = 1 : size(ListVarName,2)
        localblockname = ListVarName{ii};
        try
            ParamExist = evalin('base',['exist(''' char(localblockname) ''')']);
            if((ParamExist ~= 1) && isempty(regexp(localblockname, '^[0123456789]*', 'match')))
                evalin('base',[localblockname ' = ' Arg_ClassName '.Parameter;']);
                if(strcmpi(Arg_Rules,'Generic'))
                    Display([localblockname ' is not found in hook files so it''s Defined by generic rules.'],'info',Arg_Mode);
                end
            end
        catch
            % disp('WARNING : Constant block unnamed, no corresponding parameter is created!');
        end
    end
end

%% Generic_Create_Param_MPT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function  Generic_Create_Param_MPT(BlockId,Arg_Mode)
    List_Params = get_param(BlockId,'DialogParameters');
    assignin('base','List_Params',List_Params);
    if ~isempty(List_Params)
        List_Fields = fieldnames(List_Params);
        for i=1: length(List_Fields)
            Length_Attr = evalin('base',['length(List_Params.' List_Fields{i} '.Attributes)']);
            Val_Attr = evalin('base',['List_Params.' List_Fields{i} '.Attributes{1}']);
            Val_Type = evalin('base',['List_Params.' List_Fields{i} '.Type']);
            if((Length_Attr==1) && strcmp(Val_Attr,'read-write'))
               if strcmp(Val_Type,'string')
                   Val_Param = get_param(BlockId,List_Fields{i});
                   Is_Param_Num = str2num(Val_Param);
                   if isempty(Is_Param_Num)
                        create_parameter(BlockId,List_Fields{i},SimulinkDefaultClass,'Generic',Arg_Mode);
                   end
                end
            end
        end
    end
    evalin('base','clear List_Params');
end

% Generate hook files ;)
function UpdateBib(Arg_Path2BIB_MDL,Arg_CustomHookFilePrefix)
    BibHandle = load_system(Arg_Path2BIB_MDL);
    paths_Cell = regexp(Arg_Path2BIB_MDL,'\\','split');
    ModelName = regexprep(paths_Cell{end},'\.mdl$','');
    BlocksHandles = find_system(BibHandle,'findall','on','followlinks','On','Mask','on','BlockType','SubSystem');
    fid = fopen([Arg_CustomHookFilePrefix ModelName '.m'], 'w');
    % Hook File Header
    %********************************************************
    fprintf(fid, ['function Arg_BlockInfoStruct = ' Arg_CustomHookFilePrefix ModelName '(Arg_MaskType)' sprintf('\n')]);
    fprintf(fid, ['%s This file is auto generated by checkdata' sprintf('\n')],'%');
    fprintf(fid, ['%s This Hook file will be used by checkdata for custom modules.' sprintf('\n')],'%');
    fprintf(fid, ['%s Format Cell => MaskParameterName|Type(Signal/Parameter)|Class%' sprintf('\n')],'%');
    fprintf(fid, ['%s' sprintf('\n')],'%');
    fprintf(fid, [sprintf('\n')]);
    fprintf(fid, ['%s' sprintf('\n')],'%');
    fprintf(fid, ['%s Date: %s' sprintf('\n')],'%',datestr(now));
    fprintf(fid, ['%s Author: %s' sprintf('\n')],'%',getenv('USERNAME'));
    fprintf(fid, ['%s' sprintf('\n')],'%');
    fprintf(fid, [sprintf('\n')]);
    fprintf(fid, ['Arg_BlockInfoStruct = {}; %s Empty structure' sprintf('\n')],'%');
    fprintf(fid, ['if (nargin == 1)' sprintf('\n')]);
    fprintf(fid, ['   switch Arg_MaskType' sprintf('\n')]);
    %********************************************************
    unique = {};
    idxUnique=1;
    for idx_line=1:length(BlocksHandles) %set data logging
        % Block Name
        data_name   = get_param(BlocksHandles(idx_line),'Name');
        % MaskType
        MaskType    = get_param(BlocksHandles(idx_line),'MaskType');
        MaskDefined = FindMask(unique,MaskType);
        if(strcmpi(MaskDefined,'false'))
            unique{idxUnique} = MaskType;
            idxUnique =idxUnique+1;
            % MaskType re-get because of (UTF-8,ISO/CEI 10646)!
            MaskType    = get_param(BlocksHandles(idx_line),'MaskType');
            % Mask Values
            MaskNames  = get_param(BlocksHandles(idx_line),'MaskNames');
            % Tunnable Values
            TunabValues = get_param(BlocksHandles(idx_line),'MaskTunableValues');
            % MaskStyles
            Styles      = get_param(BlocksHandles(idx_line),'MaskStyles');
            TunnableValues = {};
            Idx=1;
            for idxValue=1:length(MaskNames)
                if((strcmpi(TunabValues{idxValue},'on'))&&(strcmpi(Styles{idxValue},'edit')))
                    TunnableValues{Idx}=MaskNames{idxValue};
                    Idx=Idx+1;
                end
            end
            if((~strcmpi(MaskType,'CMBlock'))&&(~strcmpi(MaskType,''))&&(length(TunnableValues)>0))
                MaskType = strrep(MaskType,sprintf('%s',''''),sprintf('%s',''''''));
                fprintf(fid, [ '      case ' '''' MaskType '''' sprintf('\n')]);
                for idxValue=1:length(TunnableValues)
                    fprintf(fid, [ '         Arg_BlockInfoStruct{' num2str(idxValue) '} = ' '''' TunnableValues{idxValue} '|Parameter|Simulink' '''' ';' sprintf('\n')]);
                end
            end
        end
    end
    
    %***************************************************************************
    fprintf(fid, ['      otherwise' sprintf('\n')]);
    fprintf(fid, ['         %s Do nothing' sprintf('\n')],'%');
    fprintf(fid, ['   end' sprintf('\n')]);
    fprintf(fid, ['end' sprintf('\n')]);
    fprintf(fid, ['end' sprintf('\n')]);
    fclose(fid);
    close_system(BibHandle);
end

% check if mask exist
function Arg_MaskFound = FindMask(Arg_CellList,Arg_Element)
    Arg_MaskFound = 'false';
    for idx=1:length(Arg_CellList)
        if(strcmpi(Arg_CellList{idx},Arg_Element))
            Arg_MaskFound = 'true';
        end
    end
end

% Display
function Display(Arg_Msg,Arg_Type,Arg_Mode)
    if(strcmpi(Arg_Mode,'True'))
        if(strcmpi(Arg_Type,'warning'))
            h = msgbox(Arg_Msg,Arg_Type,'warn');  % Gui Mode Warning
        elseif(strcmpi(Arg_Type,'error'))
            h = msgbox(Arg_Msg,Arg_Type,'error'); % Gui Mode Error
        else 
            h = msgbox(Arg_Msg,Arg_Type,'help');  % Gui Mode Info
        end
    else
        disp([Arg_Type ': ' Arg_Msg ]);           % Terminal
    end
end

% find already defined Hook files
function Arg_DefFileIndx = CheckDefineFile(Arg_UniqueFunction,Arg_FileName)
    Arg_DefFileIndx = 0;
    for idx=1:length(Arg_UniqueFunction)
        if(strcmpi(Arg_UniqueFunction{idx},Arg_FileName))
            Arg_DefFileIndx = idx;
        end
    end
end
%% EOF %%
