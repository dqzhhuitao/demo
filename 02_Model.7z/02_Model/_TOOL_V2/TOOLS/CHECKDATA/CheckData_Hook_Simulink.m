function Arg_BlockInfoStruct = CheckData_Hook_Simulink(Arg_MaskType)
% Main hook file of simulink library
% This Hook file will be used by checkdata for custom modules.
% Format Cell => MaskParameterName|Type(Signal/Parameter)|Class%

Arg_BlockInfoStruct = {}; % Empty structure
if (nargin == 1)
   switch Arg_MaskType
      case 'DataStoreMemory'
         Arg_BlockInfoStruct{1} = 'DataStoreName|Signal|mpt';
      case 'DataStoreWrite'
         Arg_BlockInfoStruct{1} = 'DataStoreName|Signal|mpt';
      case 'DataStoreRead'
         Arg_BlockInfoStruct{1} = 'DataStoreName|Signal|mpt';
      case 'UnitDelay'
         Arg_BlockInfoStruct{1} = 'StateIdentifier|Signal|mpt';
      case 'line'
         Arg_BlockInfoStruct{1} = 'Name|Signal|mpt';
      case 'Constant'
         Arg_BlockInfoStruct{1} = 'Value|Parameter|mpt';
      case 'Lookup'
         Arg_BlockInfoStruct{1} = 'InputValues|Parameter|mpt';
         Arg_BlockInfoStruct{2} = 'Table|Parameter|mpt';
      case 'Gain'
         Arg_BlockInfoStruct{1} = 'Gain|Parameter|mpt';
      case 'Saturate'
         Arg_BlockInfoStruct{1} = 'UpperLimit|Parameter|mpt';
         Arg_BlockInfoStruct{2} = 'LowerLimit|Parameter|mpt';
      case 'Lookup_n-D'
         Arg_BlockInfoStruct{1} = 'Table|Parameter|mpt';
         Arg_BlockInfoStruct{2} = 'BreakpointsForDimension1|Parameter|mpt';
         Arg_BlockInfoStruct{3} = 'BreakpointsForDimension2|Parameter|mpt';
         Arg_BlockInfoStruct{4} = 'BreakpointsForDimension3|Parameter|mpt';
      case 'Lookup2D'
         Arg_BlockInfoStruct{1} = 'Table|Parameter|mpt';
         Arg_BlockInfoStruct{2} = 'RowIndex|Parameter|mpt';
         Arg_BlockInfoStruct{3} = 'ColumnIndex|Parameter|mpt';
      case 'SwitchCase'
         Arg_BlockInfoStruct{1} = 'CaseConditions|Parameter|mpt';
      otherwise
         % Do nothing
   end
end
end
