function  SetVariableDefineFile(filename)
%SETVARIABLEDEFINEFILE Summary of this function goes here
%   Detailed explanation goes here
if (~isempty(filename))
    fid = fopen(filename, 'rt+');
    [FileData,count] = fscanf(fid,'%c');
    FileData = strrep(FileData,'<HeaderFile/>','<HeaderFile Class="char">''app_st_sms.h''</HeaderFile>');
    FileData = strrep(FileData,'<DefinitionFile/>','<DefinitionFile Class="char">''app_st_sms.c''</DefinitionFile>');
    fid = fopen(filename, 'wt+');
    fprintf(fid,'%c',FileData);
    fclose(fid);
    xml2ws(filename);
    disp('file save succesful!!!');
else
    dispaly('the filename is not legal')
end
   
end

